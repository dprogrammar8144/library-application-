﻿using BookStoreApi.Model;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.Repository
{
    public interface IAccountRepo
    {
        Task<IdentityResult> SignUpUser(SignUpModel signUpModel);
        Task<string> LoginUser(SigninModel signin);
    }
}
