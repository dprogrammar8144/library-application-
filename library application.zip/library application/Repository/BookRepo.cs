﻿using AutoMapper;
using BookStoreApi.Data;
using BookStoreApi.HelpersProfile;
using BookStoreApi.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.Repository
{
    public class BookRepo : IBookRepo
    {
        private readonly DbStoreContext _context;
        private readonly IMapper _mapper;

        public BookRepo(DbStoreContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<BookModel>> GetAllBooks()
        {
            var records = await _context.TabBooks.ToListAsync();
            return _mapper.Map<List<BookModel>> (records);

            //var records = await _context.TabBooks.Select(x => new BookModel() { 
            
            //id = x.id,
            //Title = x.Title,
            //Description = x.Description

                      
            //}).ToListAsync();

            //return records;
        }


        public async Task<BookModel> GetSingleBookbyid(int bookid)
        {
            var record = await _context.TabBooks.FindAsync(bookid);
            return _mapper.Map<BookModel>(record);

           // var records = await _context.TabBooks.Where(x=> x.id == bookid).Select(x => new BookModel()
           // {

            //     id = x.id,
            //     Title = x.Title,
            //     Description = x.Description

            //}).FirstOrDefaultAsync();

            // return records;
        }

        public async Task<int> AddBook(BookModel bookModel)
        {
            var book = new Books()
            {
                Title = bookModel.Title,
                Description = bookModel.Description

            };

            _context.TabBooks.Add(book);
            await _context.SaveChangesAsync();
            return book.id;

        }

        public async Task UpdateBook(int bookid, BookModel bookModel)
        {

            var book = await _context.TabBooks.FindAsync(bookid);

            if (book != null)
            {
                book.Title = bookModel.Title;
                book.Description = bookModel.Description;
               await _context.SaveChangesAsync();

            }

           }

                public async Task DeleteBookbyid(int bookid)
                {
                var book = new Books() { id = bookid };
                    

                    _context.TabBooks.Remove(book);
                    await _context.SaveChangesAsync();
            

                }

    }
    
}
