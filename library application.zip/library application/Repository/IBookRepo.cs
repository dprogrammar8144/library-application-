﻿using BookStoreApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.Repository
{
   public interface IBookRepo
    {
        Task<List<BookModel>> GetAllBooks();
        Task<BookModel> GetSingleBookbyid(int bookid);
        Task<int> AddBook(BookModel bookModel);
        Task UpdateBook(int bookid, BookModel bookModel);
        Task DeleteBookbyid(int bookid);
    }
}
