﻿using AutoMapper;
using BookStoreApi.Data;
using BookStoreApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.HelpersProfile
{
    public class AppMapper : Profile
    {
        public AppMapper()
        {
            CreateMap<Books, BookModel>().ReverseMap();
        }
    }
}
