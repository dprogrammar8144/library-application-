﻿using BookStoreApi.Model;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.Data
{
    public class DbStoreContext : IdentityDbContext<ApplicationUser>
    {
        public DbStoreContext(DbContextOptions<DbStoreContext> options) : base(options)
        {

        }

        public DbSet<Books> TabBooks { set; get; }

    }
}
