﻿using BookStoreApi.HelpersProfile;
using BookStoreApi.Model;
using BookStoreApi.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.Controllers
{
    [Route("api/books")]
    [ApiController]
    //[Authorize]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepo _iIbookRepo;


        public BooksController(IBookRepo IIbookRepo)
        {
            _iIbookRepo = IIbookRepo;
        }


        [HttpGet ("GettingAllBooks")]
        public async Task<IActionResult> GettingAllBooks()
        {

            var books = await _iIbookRepo.GetAllBooks();
            return Ok(books);
        }


        [HttpGet("GetBookbyId{id}")]
        public async Task<IActionResult> GetBookbyId([FromRoute] int id)

            {

           var singlebook = await _iIbookRepo.GetSingleBookbyid(id);

            if (singlebook == null)
            {
                return NotFound("Book Record Not Found");
            }

            return Ok(singlebook);
        }

        [HttpPost ("AddNewBook")]

        public async Task<IActionResult> AddNewBook([FromBody] BookModel bookModel)

        {
          
          var book = await _iIbookRepo.AddBook(bookModel);

            return Ok(book);

            //return CreatedAtAction(nameof(GetBookbyId), new { id = book, Controller = "books" }, book);
        }

        [HttpPut("UpdateBook{id}")]

        public async Task <IActionResult> UpdateBookByid([FromBody] BookModel bookModel, [FromRoute] int id)

        {
           

            await _iIbookRepo.UpdateBook(id, bookModel);

            return Ok(bookModel);
            }


        [HttpDelete("DeleteBook{id}")]

        public async Task<IActionResult> DeleteBook( [FromRoute] int id)

        {


            await _iIbookRepo.DeleteBookbyid(id);

            return Ok("Record Deleted Successfully");


        }

    }
}
