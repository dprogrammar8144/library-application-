﻿using BookStoreApi.Model;
using BookStoreApi.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoreApi.Controllers
{
    [Route("api/[Action]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly IAccountRepo _iacctRepository;

        public AccountController(IAccountRepo IacctRepository)
        {
            _iacctRepository = IacctRepository;
        }


        [HttpPost]
        public async Task <IActionResult> SignUp([FromBody] SignUpModel signUpModel)
        {
            var result = await _iacctRepository.SignUpUser(signUpModel);

            if (result.Succeeded)
            {
                return Ok(result.Succeeded);
            }

            return Unauthorized();
        }


         [HttpPost]
        public async Task <IActionResult> Login([FromBody] SigninModel signinModel)
        {
            var result = await _iacctRepository.LoginUser(signinModel);

          if (string.IsNullOrEmpty(result))
            {
                return Unauthorized();
            }

            return Ok(result);
        }
    }
}
